package findYourLove;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class findYourLoveTest {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
    FileWriter fw = new FileWriter("chat.txt");
	fw.write("");
    fw.flush();
    fw.close();
	}

//	@AfterClass
//	public static void tearDownAfterClass() throws Exception {
//	
//	}
//
//	@Before
//	public void setUp() throws Exception {
//	
//	}
//
//	@After
//	public void tearDown() throws Exception {
//		
//	}

	@Test
	public void Showtopic_test() throws IOException {
	    String temp = "";
		for(int i=1;i<10;i++) {
			BufferedReader hab = new BufferedReader(habbits.Returnha(i));
			while (hab.ready()) {
		          temp = temp + hab.readLine() + "\n";
		    }
			Showtopic.show(i);
			assertEquals(temp,Showtopic.getTemp());
		}
	}
	
	@Test
	public void Chat_topic_test() throws IOException {
	    String temp = "";
	    FileReader chat = new FileReader("chat.txt");
	    for(int i=1;i<10;i++) {
	    	BufferedReader habr = new BufferedReader(habbits.Returnhar(i));
	    	for(int j=1;j<4;j++) {
	    		Chat.chat(i, habr);
				BufferedReader hab = new BufferedReader(chat);
				while (hab.ready()) {
			          temp = temp + hab.readLine() + "\n";
			    }
				assertEquals(temp,Chat.getTmp());
	    	}
	   }
	}
	
	@Test
	public void Chat_yourself_test() throws IOException {
		FileReader chat = new FileReader("chat.txt");
		char[] letter  = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		char[] temp = {'a','a','a','a'};
		String word = "";
		String tmp = "";
		String temp_of_word = "";
		int i, j, k;
		for(i=0;i<4;i++) {
			for(j=0;j<26;j++) {
				temp[i] =  letter[j];
				for(k=0;k<4;k++)word = word + temp[k];
				Chat.chat_by_yourself(word);
				BufferedReader read = new BufferedReader(chat);
				while (read.ready()) {
			          tmp = tmp + read.readLine() + "\n";
			        }
				temp_of_word =temp_of_word + word + "\n";
				assertEquals(temp_of_word,tmp);
				word = "";
			}
		}
	}
}
