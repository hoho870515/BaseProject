package match;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int interest = 0;
		int temp;
		int habbit;
		int i, j;
		int[] a = { 1, 3, 4, 6 };
		int[] b = { 1, 3, 4, 6 };
		int[] c = { 1, 4, 6, 9 };
		int[] d = { 3, 4, 6, 8 };
		int[] hobby = { 0, 0, 0, 0 };

		people client = new people(0, 0, 0, 0, 0, 0, 0, 0);
		client.setHobby(hobby);
		people hung = new people(19, 1, 1, 1, 4, 1, 3, 2);
		hung.setHobby(a);
		people ling = new people(20, 1, 1, 3, 10, 1, 2, 2);
		ling.setHobby(b);
		people xiao = new people(20, 1, 1, 3, 10, 1, 2, 3);
		xiao.setHobby(c);
		people yu = new people(19, 1, 1, 2, 10, 1, 2, 3);
		yu.setHobby(d);

		System.out.println("����:1 �B�� 2 �}�� 3 �\Ū 4 �q�� 5 �i�� 6 ���� 7 ø�e 8 �g�@ 9 �ȹC(�̦h��J4��)\n ");
		hobby[0] = scanner.nextInt();
		hobby[1] = scanner.nextInt();
		hobby[2] = scanner.nextInt();
		hobby[3] = scanner.nextInt();
		System.out.println("�~��\n ");
		client.salary = scanner.nextInt();
		System.out.println("�~�~ :1 0-22000 2 22000-50000 3 50000-100000 4 100000UP\n ");
		client.age = scanner.nextInt();
		System.out.println("�嫬 :1A 2B 3O 4AB \n ");
		client.bloodType = scanner.nextInt();
		System.out.println("�P�y:1�զϮy 2�����y 3���l�y 4���ɮy 5��l�y 6�B�k�y 7�ѯ��y 8���Ȯy 9�g��y 10�]�~�y 11���~�y 12�����y\n ");
		client.sign = scanner.nextInt();
		System.out.println("¾�~:1 �ǥ� 2 �x���� 3 �W�Z�� 4 �K�j 5 �a�x�D�� 6 �ۥѷ~ \n ");
		client.job = scanner.nextInt();
		System.out.println("�ͨv:1�� 2�� 3�� 4�� 5�s 6�D 7�� 8�� 9�U 10�� 11�� 12�� \n ");
		client.chineseSign = scanner.nextInt();
		System.out.println("�a�m:1�_  2��   3�n   4�F   5���q\n ");
		client.home = scanner.nextInt();

		temp = client.findYourLove(client.checkScore(hung), client.checkScore(ling), client.checkScore(xiao),
				client.checkScore(yu));
		if (temp == 0) {
			for (i = 0; i < 4; i++) {
				for (j = 0; j < 4; j++) {
					if (client.hobby[i] == hung.hobby[j]) {
						habbit = client.hobby[i];
					}
				}
			}
		} else if (temp == 1) {
			for (i = 0; i < 4; i++) {
				for (j = 0; j < 4; j++) {
					if (client.hobby[i] == ling.hobby[j]) {
						habbit = client.hobby[i];
					}
				}
			}

		} else if (temp == 2) {
			for (i = 0; i < 4; i++) {
				for (j = 0; j < 4; j++) {
					if (client.hobby[i] == xiao.hobby[j]) {
						habbit = client.hobby[i];
					}
				}
			}

		} else if (temp == 3) {
			for (i = 0; i < 4; i++) {
				for (j = 0; j < 4; j++) {
					if (client.hobby[i] == yu.hobby[j]) {
						habbit = client.hobby[i];
					}
				}
			}

		}

	}

}
