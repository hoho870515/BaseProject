package chat;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class Main {
  public static void main(String[] argv) throws IOException {
	  File chat = new File("chat.txt");
    FileReader fr = new FileReader(chat);
    FileWriter fw = new FileWriter(chat, true);
    BufferedReader br = new BufferedReader(fr);
    Scanner scanner = new Scanner(System.in);
    int choose;
    int count = 1;
    String readLine;
    String temp;
    while (true) {
      br = new BufferedReader(new FileReader(chat));
      while (br.ready()) {
        System.out.println(br.readLine());
      }
      br.close();
      System.out.println("��ܱ��ϥΪ����D:");
      BufferedReader hab = new BufferedReader(habbits.Returnha(habbit));
      BufferedReader habr = new BufferedReader(habbits.Returnhar(habbit));
      while (hab.ready()) {
        System.out.println(hab.readLine());
      }
      br.close();
      System.out.println("(�ۦ��J�п�0,���}�п�9)");
      choose = scanner.nextInt();
      if(choose == 9)break;
      if (choose > 0) {
        while ((readLine = habr.readLine()) != null) {
          if (count < choose) {
            count++;
            continue;
          }
          fw.write(readLine + "\r\n");
          fw.flush();
          if (count >= choose) {
            break;
          }
        }
        count = 1;
      }
      habr.close();
      if (choose < 0.00001) {
    	System.out.println("(��J��Ѥ��e�A�ο�Jexit���})");
        temp = scanner.next();
        if (temp.equalsIgnoreCase("exit"))break;
        fw.write(temp + "\r\n");
        fw.flush();
        hab.close();
      }
    }
    fw.close();
    fr.close();
    System.out.println("�������");
    scanner.close();
  }
}
